#include <CL/sycl.hpp>
#include <cmath>
#include <iostream>
#include <random>

using namespace cl::sycl;

double black_scholes_call(double S, double K, double r, double div_yield, double sigma, double T) {
    double d1 = (log(S / K) + (r - div_yield + 0.5 * sigma * sigma) * T) / (sigma * sqrt(T));
    double d2 = d1 - sigma * sqrt(T);
    double Nd1 = 0.5 * erfc(-d1 / sqrt(2.0));
    double Nd2 = 0.5 * erfc(-d2 / sqrt(2.0));
    return S * exp(-div_yield * T) * Nd1 - K * exp(-r * T) * Nd2;
}

double black_scholes_put(double S, double K, double r, double div_yield, double sigma, double T) {
    double d1 = (log(S / K) + (r - div_yield + 0.5 * sigma * sigma) * T) / (sigma * sqrt(T));
    double d2 = d1 - sigma * sqrt(T);
    double Nd1 = 0.5 * erfc(d1 / sqrt(2.0));
    double Nd2 = 0.5 * erfc(d2 / sqrt(2.0));
    return K * exp(-r * T) * Nd2 - S * exp(-div_yield * T) * Nd1;
}

int main() {
    double S0 = 100.0;
    double K = 100.0;
    double r = 0.05;
    double div_yield = 0.02;
    double sigma = 0.25;
    double T = 1.0;
    int N = 10000;
    int M = 50;
    int option_type = 1;

    queue q{ cpu_selector{} };

    std::vector<double> rand_nums(N * M);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::normal_distribution<> dis(0, 1);

    for (int i = 0; i < N * M; ++i) {
        rand_nums[i] = dis(gen);
    }

    buffer<double> rand_nums_buf{ rand_nums };
    buffer<double> result_buf{ range{1} };

    double dt = T / M;

    q.submit([&](handler& h) {
        auto rand_nums_acc = rand_nums_buf.get_access<access::mode::read>(h);
        auto result_acc = result_buf.get_access<access::mode::write>(h);

        h.single_task<class MonteCarloKernel>([=]() {
            double sum = 0.0;
            for (int i = 0; i < N; ++i)
            {
                double S = S0;
                for (int j = 0; j < M; ++j) {
                    double rand_num = rand_nums_acc[i * M + j];
                    S *= exp((r - div_yield - 0.5 * sigma * sigma) * dt + sigma * sqrt(dt) * rand_num);
                }

                double payoff = 0.0;
                if (option_type == 1) {
                    payoff = std::max(S - K, 0.0);
                }
                else if (option_type == 2) {
                    payoff = std::max(K - S, 0.0);
                }
                sum += payoff;
            }
            double result = sum / N;
            result_acc[0] = result;
                        });
            });

        double option_price_cpu = exp(-r * T) * result_buf.get_access<access::mode::read>()[0];
        std::cout << "CPU result: " << option_price_cpu << std::endl;
        double analytical_result = 0.0;
        if (option_type == 1) {
            analytical_result = black_scholes_call(S0, K, r, div_yield, sigma, T);
            std::cout << "Analytical result: " << analytical_result << std::endl;
        }
        else if (option_type == 2) {
            analytical_result = black_scholes_put(S0, K, r, div_yield, sigma, T);
            std::cout << "Analytical result: " << analytical_result << std::endl;
        }

        double error = abs(option_price_cpu - analytical_result) / analytical_result * 100.0;
        std::cout << "Relative error: " << error << "%\n";

        if (error < 1.0) {
            std::cout << "The result is good, with a relative error below 1%." << std::endl;
        }
        else {
            std::cout << "The result has a relative error above 1%. Consider increasing the number of simulations or steps for a more accurate result." << std::endl;
        }

        return 0;
}








